﻿using System;
using System.Net;
using System.Web.Http;
using RestApi.Interfaces;
using RestApi.Models;
using System.Data.Entity;
using System.Linq;
using System.Net.Http;

namespace RestApi.Controllers
{
    public class PatientsController : ApiController
    {

        #region Private members

        private IDatabaseContext _context = default(IDatabaseContext);

        #endregion

        #region Constructors

        public PatientsController(IDatabaseContext context)
        {
            _context = context;
        }

        #endregion

        #region Actions

        [HttpGet]
        public Patient Get(int patientId)
        {
            var returnValue = null as Patient;

            if(patientId <= 0)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            try
            {
                var patientsWithEpisodes = (from p in _context.Patients
                                            join e in _context.Episodes on p.PatientId equals e.PatientId
                                            where p.PatientId == patientId
                                            select new { p, e });

                if (patientsWithEpisodes != null && patientsWithEpisodes.Any())
                {
                    returnValue = patientsWithEpisodes.First().p;
                    returnValue.Episodes = patientsWithEpisodes.Select(x => x.e).ToList();
                }

            }
            catch(Exception ex)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }

            return returnValue;
        }

        #endregion

    }
}