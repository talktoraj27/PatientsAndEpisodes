This repository contains code for assessments for Careflow Connect candidates.

The instructions to the assessor are found in 'Instructions for the assessor.txt'. This file describes the assessments available, and how to prepare them for the candidates.

The instructions to the candidate are found in 'Instructions for the candidate.txt'. This file describes the solution a little, and asks the candidate to implement some feature.